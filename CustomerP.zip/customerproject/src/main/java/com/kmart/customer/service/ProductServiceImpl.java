package com.kmart.customer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kmart.customer.repo.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{

	
	    @Autowired
	    private ProductRepository productRepository;

	    @Override
	    public void deleteProduct(Long id) {
	        productRepository.deleteById(id);
	    }

	    
	


}
