package com.kmart.customer.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kmart.customer.dto.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {

}
