package com.kmart.customer.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kmart.customer.dto.CustomerInvoice;

public interface CustomerRepo extends JpaRepository<CustomerInvoice, Integer>{
	
}
