package com.kmart.customer.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kmart.customer.dto.CustomerInvoice;
import com.kmart.customer.repo.CustomerRepo;

@Repository
public class CustomerDao {
	@Autowired
	private CustomerRepo repo;

	public CustomerInvoice saveCustomer(CustomerInvoice customer) {
		return repo.save(customer);
	}

	public CustomerInvoice findCustomer(int id) {
		Optional<CustomerInvoice> o = repo.findById(id);
		if (o.isPresent()) {
			return o.get();
		} else {
			return null;
		}
	}

	public CustomerInvoice deleteCustomer(int id) {
		Optional<CustomerInvoice> o = repo.findById(id);
		if (o.isPresent()) {
			repo.deleteById(id);
			return o.get();
		}
		return null;
	}
}
