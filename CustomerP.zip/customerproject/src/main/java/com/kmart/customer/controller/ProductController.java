package com.kmart.customer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kmart.customer.service.ProductService;

@RestController
@RequestMapping("/product-service")
public class ProductController {

	@Autowired
	private ProductService service;
	
	@DeleteMapping("/deleteproduct")
	public ResponseEntity<String> deleteProduct(@RequestParam Long id) {
		service.deleteProduct(id);
		return ResponseEntity.ok("deleted Sucessfully");
	}
}
