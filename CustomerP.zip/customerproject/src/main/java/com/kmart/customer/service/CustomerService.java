package com.kmart.customer.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kmart.customer.dao.CustomerDao;
import com.kmart.customer.dto.CustomerInvoice;
import com.kmart.customer.dto.Product;
@Service
public class CustomerService {
	@Autowired
	private CustomerDao dao;
	public CustomerInvoice saveCustomer(CustomerInvoice customerInvoice) {
		Double totalAmount= 0.0;
		List<Product> finalProductList = new ArrayList<>();
		for(Product product :  customerInvoice.getProducts()) {
			Double amount= product.getQty() * product.getPrice();
			product.setAmount(amount);
			totalAmount += amount;
			finalProductList.add(product);
		}
		customerInvoice.setProducts(finalProductList);
		customerInvoice.setTotalAmount(totalAmount);
		return dao.saveCustomer(customerInvoice);
	}
	
	
	public CustomerInvoice findCustomer(int id) {
		CustomerInvoice customer=dao.findCustomer(id);
		return customer;
	}
	public CustomerInvoice deleteCustomer(int id) {
		return dao.deleteCustomer(id);
	}




	
}
