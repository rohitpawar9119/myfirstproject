package com.kmart.customer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kmart.customer.dto.CustomerInvoice;
import com.kmart.customer.service.CustomerService;

@RestController
@RequestMapping("/customer-service")
public class CustomerController {
	@Autowired
	private CustomerService service;

	@PostMapping("/save")
	public CustomerInvoice saveCustomer(@RequestBody CustomerInvoice customerInvoice) {
		return service.saveCustomer(customerInvoice);
	}

	@GetMapping("/getcust/{id}")
	public CustomerInvoice findCustomer(@PathVariable int id) {
		return service.findCustomer(id);
	}

	@DeleteMapping("/deletecust")
	public ResponseEntity<String> deleteCustomer(@RequestParam int id) {
		service.deleteCustomer(id);
		return ResponseEntity.ok("deleted Sucessfully");
	}
	
}
