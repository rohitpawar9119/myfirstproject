package com.kmart.customer.service;

import org.springframework.stereotype.Service;

@Service
public interface ProductService {


	 void deleteProduct(Long id);
		
		
}
